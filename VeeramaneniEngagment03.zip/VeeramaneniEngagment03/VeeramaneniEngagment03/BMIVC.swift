//
//  ViewController.swift
//  VeeramaneniEngagment03
//
//  Created by Veeramaneni,Pradeep Rao on 4/6/23.
//

import UIKit

class BMIVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        heightPicker.delegate = self
        heightPicker.dataSource = self
    }


    @IBOutlet weak var ageTF: UITextField!
    
    
    @IBOutlet weak var weightTF: UITextField!
    
    
    @IBOutlet weak var heightPicker: UIPickerView!
    
    
    @IBOutlet weak var messageLBL: UILabel!
    
    
    @IBAction func onCalculate(_ sender: UIButton) {
//         let age = Double(ageTF.text!) ?? 0
            let weight = Double(weightTF.text!) ?? 0
                
            let feet = heightPicker.selectedRow(inComponent: 0)
            let inches = heightPicker.selectedRow(inComponent: 1)-1
        
        
           let height = Double(feet * 12 + inches)
               
           let bmi = (weight * 703) / (height * height)
                
            
            messageLBL.text = "Your Body Mass Index is:\(String(format: "%.1f", bmi))"
        
    }
    
    @IBAction func onReset(_ sender: UIButton) {
        ageTF.text = ""
                weightTF.text = ""
                heightPicker.selectRow(0, inComponent: 0, animated: true)
                heightPicker.selectRow(0, inComponent: 1, animated: true)
                messageLBL.text = ""
    }
    
    
}

extension BMIVC:UIPickerViewDelegate,UIPickerViewDataSource
{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 2
        }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            // First component is for feet
            return 100
        } else {
            // Second component is for inches
            return 100
        }
    }
       

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            // First component is for feet
            if row == 0 {
                return "Feet"
            } else {
                return "\(row)"
            }
        } else {
            // Second component is for inches
            if row == 0 {
                return "Inch"
                } else {
                    return "\(row-1)"
                }
            }
        }
}

