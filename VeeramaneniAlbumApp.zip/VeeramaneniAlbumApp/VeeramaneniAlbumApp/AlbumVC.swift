//
//  ViewController.swift
//  VeeramaneniAlbumApp
//
//  Created by Veeramaneni,Pradeep Rao on 3/23/23.
//

import UIKit
import AVFoundation
class AlbumVC: UIViewController,UIScrollViewDelegate{
    //var tag=0
    override func viewDidLoad() {
        super.viewDidLoad()
       
        for (i, vehicle) in vehicles.enumerated(){
            let image = UIImage(named: AppConstants.vehicles[i].0)
            vehicle.imageView.isUserInteractionEnabled=true
            vehicle.imageView.image = image
            vehicle.imageDescription = AppConstants.vehicles[i].1
            vehicle.likeLBL.text = ""
            vehicle.tag=i
            vehicle.likeLBL.isHidden = true
            let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
            vehicle.addGestureRecognizer(longPressRecognizer)
            vehicle.imageView.contentMode = .scaleToFill
        }
        
        self.scrollView.delegate = self
       // scrollView.minimumZoomScale = 1/25
       // scrollView.maximumZoomScale = 1.0
    }
    
    @IBOutlet weak var scrollView: UIScrollView!
        
            
     
    
    
    @IBOutlet weak var contentView: UIView!
    
    
    
    
   
    @IBOutlet var vehicles: [PhotoView]!
      
    
    @objc private func handleLongPress(_ sender: UILongPressGestureRecognizer) {
   
        
        if sender.state == .began, let photoView = sender.view as? PhotoView {
                   // Play an appropriate sound
                   AudioServicesPlaySystemSound(SystemSoundID(1302))
                   // Perform the segue to ImageDescVC with the tag of the long pressed photo view
                   performSegue(withIdentifier: "imageDeets", sender: photoView.tag)
               }
    }
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "imageDeets", let tag = sender as? Int, let imageDescVC = segue.destination as? ImageDescVC {
                       imageDescVC.selectedVehicleIndex = tag
                   }
        }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
            return contentView
        }
}
