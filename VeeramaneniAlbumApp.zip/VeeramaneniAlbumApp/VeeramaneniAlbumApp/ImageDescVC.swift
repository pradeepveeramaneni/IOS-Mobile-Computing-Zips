//
//  ImageDescVC.swift
//  VeeramaneniAlbumApp
//
//  Created by Veeramaneni,Pradeep Rao on 3/23/23.
//

import UIKit

class ImageDescVC: UIViewController {

    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var descTV: UITextView!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
        var selectedVehicleIndex: Int?
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            imageView.isUserInteractionEnabled = true
            guard let selectedVehicleIndex = selectedVehicleIndex else { return }
                let selectedVehicle = AppConstants.vehicles[selectedVehicleIndex]
                
                imageView.image = UIImage(named: selectedVehicle.0)
                descTV.text = selectedVehicle.1
                imageView.layer.cornerRadius = 40.0
            
            let upSwipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(didSwipeUp(_:)))
            upSwipeGesture.direction = .up
            imageView.addGestureRecognizer(upSwipeGesture)
            
            let downSwipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(didSwipeDown(_:)))
            downSwipeGesture.direction = .down
            imageView.addGestureRecognizer(downSwipeGesture)
        }
        
        @objc private func didSwipeUp(_ gestureRecognizer: UISwipeGestureRecognizer) {
            guard gestureRecognizer.state == .ended else { return }
            imageView.transform = CGAffineTransform(scaleX: 3.0, y: 3.0)
        }
        
        @objc private func didSwipeDown(_ gestureRecognizer: UISwipeGestureRecognizer) {
            guard gestureRecognizer.state == .ended else { return }
            imageView.transform = CGAffineTransform.identity
        }

    }


