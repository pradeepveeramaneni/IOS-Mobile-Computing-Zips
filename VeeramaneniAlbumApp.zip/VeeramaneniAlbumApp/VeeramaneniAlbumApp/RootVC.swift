//
//  RootVC.swift
//  VeeramaneniAlbumApp
//
//  Created by Veeramaneni,Pradeep Rao on 3/23/23.
//

import UIKit

class RootVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        //   loginBTN.configuration?.background.backgroundColor = .opaqueSeparator
        passwordTF.isSecureTextEntry=true
        passwordTF.isEnabled = false
        loginBTN.isEnabled = false
        userNameTF.addTarget(self, action: #selector(isValidName), for: .editingChanged)
        passwordTF.addTarget(self, action: #selector(isValidPassword), for: .editingChanged)
    }
    
    @IBOutlet weak var userNameTF: UITextField!
    
    
    @IBOutlet weak var loginBTN: UIButton!
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    @IBOutlet weak var passwordTF: UITextField!
    
    
    
    
    
    @IBAction func login(_ sender: Any) {
        
        self.performSegue(withIdentifier: "showAlbum", sender: self)
    }
    
    
    @objc  func isValidName() {
        
        if userNameTF.text == AppConstants.username {
        
            passwordTF.isEnabled=true
        }
        else{
            passwordTF.text?.removeAll()
            passwordTF.isEnabled=false
        }
        
    }
    
    @objc func isValidPassword() {
        
        if passwordTF.text == AppConstants.password && userNameTF.text == AppConstants.username{
            
            loginBTN.isEnabled=true
        }
        else
        {
            loginBTN.isEnabled=false
        }
    }
 

    
}


