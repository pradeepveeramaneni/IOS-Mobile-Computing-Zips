//
//  PhotoView.swift
//  VeeramaneniAlbumApp
//
//  Created by Veeramaneni,Pradeep Rao on 3/25/23.
//

import UIKit
class PhotoView: UIView {
     var imageDescription : String = ""
     
     
     @IBOutlet weak var likeLBL: UILabel!
     
     @IBOutlet weak var imageView: UIImageView!
     
    var isLiked = false {
        didSet{
            likeLBL.isHidden=false
                likeLBL.text = isLiked ? "❤️" : ""
            }
        }
    override init(frame: CGRect) {
            super.init(frame: frame)
            commonInit()
        }
        
        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            commonInit()
        }
        
        private func commonInit() {
            let nib = UINib(nibName: "PhotoView", bundle: nil)
            guard let view = nib.instantiate(withOwner: self, options: nil).first as? UIView else {
                return
            }
            
            view.frame = self.bounds
            view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            self.addSubview(view)
            imageView.isUserInteractionEnabled = true
            customizeAppearance()
            
        }
        
        // MARK: - Customization
        
        func customizeAppearance() {
            self.backgroundColor = UIColor.white
            self.layer.cornerRadius = 10.0
            self.layer.borderColor = UIColor.darkGray.cgColor
            self.layer.borderWidth = 2.0
            likeLBL.isHidden = true
            let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
            doubleTapGesture.numberOfTapsRequired = 2
            imageView.addGestureRecognizer(doubleTapGesture)
            imageView.isUserInteractionEnabled = true
        }
        
        // MARK: - Actions
        
    @objc private func handleDoubleTap(_ gesture: UITapGestureRecognizer) {
      
            isLiked.toggle()
        }
     
     
     
 }
