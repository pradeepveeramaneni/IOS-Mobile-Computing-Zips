//
//  ViewController.swift
//  VeeramaneniListApp
//
//  Created by Veeramaneni,Pradeep Rao on 2/21/23.
//

import UIKit

class ListVC: UIViewController ,UITextFieldDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     //   self.listTV.text=""
            itemQuantityTF.isEnabled = false
               addBTN.isEnabled = false
               itemNumTF.isEnabled = false
               clearBTN.isEnabled = false
               deleteBTN.isEnabled = false
               // Set up text field delegate for item name text field
               itemTF.delegate = self
        itemQuantityTF.delegate=self
        
        
    
    }
       
    
    
    @IBOutlet weak var listTV: UITextView!
    

    @IBOutlet weak var itemTF: UITextField!
    
    @IBOutlet weak var itemQuantityTF: UITextField!
    
    @IBOutlet weak var itemNumTF: UITextField!
   var i=0,count=0,j=0
    var arr:[String]=[]
    var arr1:[String]=[]
    @IBAction func addToList(_ sender: Any){
        
            itemNumTF.isEnabled = true
            clearBTN.isEnabled = true
            deleteBTN.isEnabled = true
            if(arr == []){
                self.listTV.text!="List of grocery items:\n"
                
                
                arr = ["\(self.itemTF.text!) - \(self.itemQuantityTF.text!)"]
                
                arr1 = ["\(self.itemTF.text!) - \(self.itemQuantityTF.text!)"]
                
            }
            else {
                j=j+1
                arr  = ["\(self.itemTF.text!)- \(self.itemQuantityTF.text!)"]
                arr1 += ["\(self.itemTF.text!)- \(self.itemQuantityTF.text!)"]
                
            }
            
            for item in arr{
                count=count+1
                self.listTV.text! += "\n \(count)."+item
            }
           self.itemQuantityTF.text=""
           self.itemTF.text=""
           self.itemNumTF.text=""
           itemQuantityTF.isEnabled = false
           addBTN.isEnabled = false
        
        }
    
    
    
    @IBOutlet weak var addBTN: UIButton!
    
    
    @IBAction func clear(_ sender: Any) {
        
        self.listTV.text.removeAll()
        self.itemNumTF.text?.removeAll()
        self.itemTF.text?.removeAll()
        self.itemQuantityTF.text?.removeAll()
        if(!arr1.isEmpty)
        {
            arr1.removeAll()
            count=0
            arr.removeAll()
             i=0
            self.listTV.text = "Please enter the item name and quantity, and click on the plus sign to add the item to the grocery list."
        }
        self.itemQuantityTF.text=""
        self.itemTF.text=""
        self.itemNumTF.text=""
        itemQuantityTF.isEnabled = false
           addBTN.isEnabled = false
           itemNumTF.isEnabled = false
           clearBTN.isEnabled = false
           deleteBTN.isEnabled = false
    }
    
    @IBOutlet weak var clearBTN: UIButton!
    

    @IBAction func deleteFromList(_ sender: Any) {
        
        if(!arr1.isEmpty)
        {
            var a = Int(self.itemNumTF.text!)!
            a=a-1
          
            
            print(arr1.count)
            if(!arr1.isEmpty)
            {
                arr1.remove(at: a)
                count=0
                if(arr1.isEmpty)
                {
                    self.itemQuantityTF.text=""
                    self.itemTF.text=""
                    self.itemNumTF.text=""
                    itemQuantityTF.isEnabled = false
                       addBTN.isEnabled = false
                       itemNumTF.isEnabled = false
                       clearBTN.isEnabled = false
                       deleteBTN.isEnabled = false
                    arr.removeAll()
                    arr1.removeAll()
                    count=0
                    i=0
                    self.listTV.text = "Please enter the item name and quantity, and click on the plus sign to add the item to the grocery list."
                }
            }
            if(!arr1.isEmpty)
            {
                self.listTV.text!="List of grocery items:\n"
                for item in arr1{
                    count = count+1
                    self.listTV.text! += "\n \(count)."+item
                }
            }
            else
            {
                self.listTV.text = "Please enter the item name and quantity, and click on the plus sign to add the item to the grocery list."
            }
        }
        else
        {
            self.itemQuantityTF.text=""
            self.itemTF.text=""
            self.itemNumTF.text=""
            itemQuantityTF.isEnabled = false
               addBTN.isEnabled = false
               itemNumTF.isEnabled = false
               clearBTN.isEnabled = false
               deleteBTN.isEnabled = false
            arr.removeAll()
            arr1.removeAll()
            count=0
            i=0
        }
    }
    
    @IBOutlet weak var deleteBTN: UIButton!
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == itemTF {
            itemQuantityTF.isEnabled = true
            itemQuantityTF.becomeFirstResponder()
        } else if textField == itemQuantityTF {
                addBTN.isEnabled = true
                addBTN.becomeFirstResponder()
            }
        
        return true
        

    }
}

