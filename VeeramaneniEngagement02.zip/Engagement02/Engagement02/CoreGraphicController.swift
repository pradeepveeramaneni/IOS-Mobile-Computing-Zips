//
//  ViewController.swift
//  Engagement02
//
//  Created by Veeramaneni,Pradeep Rao on 3/18/23.
//

import UIKit

class CoreGraphicController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
             // Do any additional setup after loading the view.
             let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
             containerView.center = view.center

              // Create the circle layer filled with blue color
              let circlePath = UIBezierPath(arcCenter: CGPoint(x: containerView.bounds.midX, y: containerView.bounds.midY), radius: 150, startAngle: 0, endAngle: CGFloat(Double.pi * 2), clockwise: true)
              let circleLayer = CAShapeLayer()
              circleLayer.path = circlePath.cgPath
              circleLayer.fillColor = UIColor.blue.cgColor
              containerView.layer.addSublayer(circleLayer)

            // Create the white p shaped-letter layer inside circle
            let pLetterPath = UIBezierPath()
            pLetterPath.move(to: CGPoint(x: 100, y: 80))
            pLetterPath.addLine(to: CGPoint(x: 90, y: 200))
            pLetterPath.addLine(to: CGPoint(x: 125, y: 200))
            pLetterPath.addLine(to: CGPoint(x: 130, y: 160))
            pLetterPath.addQuadCurve(to: CGPoint(x: 100, y: 80), controlPoint: CGPoint(x: 300, y: 80))
            //pLetterPath.addArc(withCenter: CGPoint(x: 180, y: 150), radius: 10, startAngle: CGFloat.pi*3/2, endAngle: CGFloat.pi*2, clockwise: true)
           //   pLetterPath.addQuadCurve(to: CGPoint(x: 230, y: 100), controlPoint: CGPoint(x: 200, y: 100))
              pLetterPath.addLine(to: CGPoint(x: 180, y: 100))
            //  pLetterPath.addLine(to: CGPoint(x: 180, y: 100))
            //  pLetterPath.addLine(to: CGPoint(x: 130, y: 120))
            //  pLetterPath.addLine(to: CGPoint(x: 230, y: 120))
          
              pLetterPath.close()

           // Create the green P shaped-letter shadowing the layer white P letter layer inside circle
            let pLetterLayer = CAShapeLayer()
            pLetterLayer.path = pLetterPath.cgPath
            pLetterLayer.fillColor = UIColor.white.cgColor
            pLetterLayer.lineWidth = 3
            pLetterLayer.shadowColor = UIColor.green.cgColor
            pLetterLayer.shadowOpacity = 1.0
            pLetterLayer.shadowRadius = 0
            pLetterLayer.shadowOffset = CGSize(width: 40.0, height: 20.0)

            containerView.layer.addSublayer(pLetterLayer)

              // Add the container view to the view controller's view
              view.addSubview(containerView)
    }


}

