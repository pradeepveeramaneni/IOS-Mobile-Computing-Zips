//
//  Model.swift
//  RecipeFinderApp
//
//  Created by Chandra on 7/11/23.
//

import Foundation
import UIKit
import Alamofire

/*
     API: TheMealDB (https://www.themealdb.com/api.php)
     List of Categories: https://www.themealdb.com/api/json/v1/1/list.php?c=list
     List of Meal for each category: https://www.themealdb.com/api/json/v1/1/filter.php?c=Seafood
     Details of each Meal: https://www.themealdb.com/api/json/v1/1/lookup.php?i=52772
 */

struct Constants {
    
    /*
         Defines the Category object
         strCategory: Name of the category
     */
    struct Category: Codable {
        var strCategory: String
    }
    
    
    /*
         Defines a Meal of each category
         strMeal: Name of the meal
         strMealThumb: Hyperlink of the meal image
         idMeal: Unique identifier (number) for each meal
     */
    struct Meals: Codable {
        var strMeal: String
        var strMealThumb: String
        var idMeal: String
    }
    
    
    /*
         Defines the details of each meal
         strMeal: Name of the meal
         strCategory: Name of the category it belongs too
         strArea: Originated region of the meal
         strInstructions: Steps to prepare the meal
         strMealThumb: Hyperlink of the meal image
         strYoutube: URL of the Youtube video of the meal
     */
    struct MealDetails: Codable {
        var strMeal: String = ""
        var strCategory: String = ""
        var strArea: String = ""
        var strInstructions: String = ""
        var strMealThumb: String = ""
        var strYoutube: String = ""
    }
    
    /* Stores all the categories retrieved from the API */
    static var categoriesFromAPI: [String] = []{
        didSet{
            print("Categories are set at : \(categoriesFromAPI.count)")
            Task{
                await loadMeals(for: categoriesFromAPI)
            }
        }
    }
    
    /* Stores all the meal of a category retrieved from the API */
    static var mealsForACategory: [String : [Meals]] = [:]
    
    /* Stores all the meal details retrieved from the API */
    static var mealDeetsForMealIDs: [String: MealDetails] = [:]
    
    
    /* Retrieves the list of categories from the API */
    static func loadCategories() async{
        
        // Splitting the url
        var apiComponents = URLComponents()
        apiComponents.scheme = "https"
        apiComponents.host = "www.themealdb.com"
        apiComponents.path = "/api/json/v1/1/list.php"
        apiComponents.queryItems = [URLQueryItem(name: "c", value: "list")]
        
        // A temporary variable to store the categories
        var categoryNames = [String]()
        
        /*
         Request the data from API
         Output from API: [String: [Category]]
         {
             "meals": [
                 {
                    "strCategory": "Beef"
                 },
                 {
                    "strCategory": "Breakfast"
                 },
             ]
         }
         */
        let task = AF.request(apiComponents.url!, method: .get).serializingDecodable([String: [Category]].self)
        let response = await task.response
        
        // Getting the category names from the output
        guard let categoriesList = response.value, let categories = categoriesList["meals"] else {return}
        categories.forEach{ category in
            categoryNames.append((category.strCategory))
        }
        
        // Storing them locally
        categoriesFromAPI = categoryNames
    }
    
    
    /* Retrieve the list of meals for all the categories */
    static func loadMeals(for categories: [String]) async {
        
        // Splitting the url
        var apiComponents = URLComponents()
        apiComponents.scheme = "https"
        apiComponents.host = "www.themealdb.com"
        apiComponents.path = "/api/json/v1/1/filter.php"
        
        // A temporary variable to store the meals
        var data: [String: [Meals]] = [:]
        
        // For each category, get the list of meals
        for cat in categories {
            
            // Query parameter is the category name
            apiComponents.queryItems = [URLQueryItem(name: "c", value: "\(cat)")]
            
            /*
             Request the data from API
             Output from API: [String: [Category]]
             {
                 "meals": [
                     {
                         "strMeal": "Baked salmon with fennel & tomatoes",
                         "strMealThumb": "https://www.themealdb.com/images/media/meals/1548772327.jpg",
                         "idMeal": "52959"
                     },
                     {
                         "strMeal": "Cajun spiced fish tacos",
                         "strMealThumb": "https://www.themealdb.com/images/media/meals/uvuyxu1503067369.jpg",
                         "idMeal": "52819"
                     },
                 ]
             }
             */
            let task = AF.request(apiComponents.url!, method: .get).serializingDecodable([String: [Meals]].self)
            let response = await task.response
            
            // Getting the list of meals from the output
            guard let mealsList = response.value, let meals = mealsList["meals"] else {return}
            data[cat] = meals
        }
        
        // Storing them locally
        mealsForACategory = data
    }
    
    
    /* Calling the function to get the details of each meal for a particular category */
    static func triggerLoadMealDetails(categoryName : String){
        Task{
            await loadMealDetails(for: categoryName)
        }
    }
    
    /* Get the id of each meal in a category - ID is useful for getting the meal details */
    static func getMealIds(for category: String) -> [String]{
        var data: [String] = []
        for (cat, ids) in Constants.mealsForACategory{
            if cat == category{
                for id in ids{
                    data.append(id.idMeal)
                }
            }
        }
        return data
    }
    
    /* Calling the function to get the details of meal for each meal id of a category */
    static func loadMealDetails(for category: String) async {
        await withTaskGroup(of: Void.self) { group in
            for mealId in getMealIds(for: category){
                group.addTask {
                    await self.loadMeadDetails(of: mealId)
                }
            }
        }
    }
    
    /* Retrieve the details of a particular meal from the API */
    static func loadMeadDetails(of meadId: String) async {
        
        // Optional handling
        if let _ = mealDeetsForMealIDs[meadId] {
            return
        }
        
        // Splitting the url
        var apiComponents = URLComponents()
        apiComponents.scheme = "https"
        apiComponents.host = "www.themealdb.com"
        apiComponents.path = "/api/json/v1/1/lookup.php"
        
        // Query paramter will be meal id
        apiComponents.queryItems = [URLQueryItem(name: "i", value: "\(meadId)")]
        
        /*
         Request the data from API
         Output from API: [String: [Category]]
         {
             "meals": [
                 {
                      "strMeal": "Teriyaki Chicken Casserole",
                      "strCategory": "Chicken",
                      "strArea": "Japanese",
                      "strInstructions": "Cook the chicken",
                      "strTags": "Meat,Casserole",
                      "strYoutube": "https://www.youtube.com/watch?v=4aZr5hZXP_s",
                 }
             ]
         }
         */
        let task = AF.request(apiComponents.url!, method: .get).serializingDecodable([String: [MealDetails]].self)
        let response = await task.response
        print(response)
        
        // Getting the meal details from the output
        guard let mealsList = response.value, let meals = mealsList["meals"] else {
            print("Failed to load meal details for meal ID: \(meadId)")
            return
        }
        
        // Storing them locally
        mealDeetsForMealIDs[meadId] = meals[0]
    }
    
    
    static func handleResponse(data: Data?, response: URLResponse?) -> Data?{
        guard let data = data, let response = response as? HTTPURLResponse, response.statusCode >= 200 && response.statusCode < 300 else {return nil}
        return data
    }
    
    static func setData() async {
        Task(priority: .userInitiated){
            await Constants.loadCategories()
        }
    }
    
    // Storing the fav dishes
    static var favoriteMeals: [String: [FavoriteMealDetails]] = [:]
    
    // Define a struct to store favorite meal details
    struct FavoriteMealDetails : Codable {
        var name: String
        var thumb: String
        var isFavorite: Bool
    }
}
