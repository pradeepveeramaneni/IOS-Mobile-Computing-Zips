//
//  RecipeDetailsVCViewController.swift
//  DoddaRecipeFinderApp
//
//  Created by Aashritha Dodda on 11/2/23.
//

import UIKit

class RecipeDetailsVC: UIViewController {
    
    
    
    @IBOutlet weak var mealNameLBL: UILabel!
    
    
    @IBOutlet weak var areaLBL: UILabel!
    
    @IBOutlet weak var categoryLBL: UILabel!
    
    @IBOutlet weak var recipeTV: UITextView!
    
    @IBOutlet weak var mealIV: UIImageView!
    
    
    @IBOutlet weak var addFavorite: UIBarButtonItem!
    
    
    
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
