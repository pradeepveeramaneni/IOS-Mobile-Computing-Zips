//
//  HomeVC.swift
//  DoddaRecipeFinderApp
//
//  Created by Aashritha Dodda on 11/2/23.
//

import UIKit
import Lottie


class HomeVC: UIViewController {
    
    

    
    
    @IBOutlet weak var animationView: LottieAnimationView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Home"
        
        
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop
        animationView.play()
        
//        self.recipeAnimationView = recipeAnimationView(name: "animation") // Replace "animation" with your actual animation file name
//
//           // Configure the animation view
//           recipeAnimationView.loopMode = .loop // Play the animation in a loop
//           recipeAnimationView.contentMode = .scaleAspectFit
//           recipeAnimationView.frame = view.bounds
//
//           // Add the animation view to your view controller's view
//           view.addSubview(recipeAnimationView)

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
